이전 스피카 Codex Pet v2 보존본입니다.
현재 G 기본형은 상위 폴더의 spica-improved-v2.zip을 사용하세요.
