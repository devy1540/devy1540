스피카 G Codex Pet v2

spica-improved-v2 폴더를 ~/.codex/pets/ 아래에 복사합니다.
pet.json과 spritesheet.webp는 같은 폴더에 둡니다.
이 ZIP은 아트워크이며 앱 설정을 변경하지 않습니다.
세부 자료와 검수 기록은 저장소의 assets/devy/pet-v2/README.md를 참고하세요.
